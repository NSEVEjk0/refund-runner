import json

def norm(text):
    if text is None:
        return ''
    return ' '.join(str(text).casefold().split())

def process_job(job):
    claim = job.get('claim', {})
    rows = job.get('rows', [])

    amount_cents = claim.get('amount_cents', 0)
    currency = claim.get('currency')
    aliases = claim.get('merchant_aliases', []) or []
    order_ref = norm(claim.get('order_reference', ''))
    refund_ref = norm(claim.get('refund_reference', ''))
    refs = {r for r in (order_ref, refund_ref) if r}
    credit_sign = claim.get('credit_sign')

    relevant = []
    for row in rows:
        amt = row.get('amount_cents', 0)
        if amt == 0:
            continue
        if credit_sign == 'negative':
            if amt >= 0:
                continue
        elif credit_sign == 'positive':
            if amt <= 0:
                continue
        else:
            continue

        desc_n = norm(row.get('description', ''))
        ref_n = norm(row.get('reference', ''))
        ref_match = bool(ref_n) and ref_n in refs
        merchant_match = desc_n in aliases
        if ref_match or merchant_match:
            relevant.append({
                'row': row,
                'desc_n': desc_n,
                'ref_n': ref_n,
                'ref_match': ref_match,
                'merchant_match': merchant_match,
            })

    groups = {}
    for item in relevant:
        row = item['row']
        key = (
            row.get('date'),
            item['desc_n'],
            item['ref_n'],
            row.get('amount_cents'),
            row.get('currency'),
            row.get('status'),
        )
        groups.setdefault(key, []).append(item)

    duplicate_ids = set()
    for items in groups.values():
        if len(items) > 1:
            for item in items:
                duplicate_ids.add(item['row'].get('id'))

    matched_rows = []
    pending_rows = []
    review_rows = []
    posted_credit_cents = 0
    pending_credit_cents = 0

    for item in relevant:
        row = item['row']
        row_id = row.get('id')
        is_duplicate = row_id in duplicate_ids
        lacks_ref = not item['ref_match']
        different_currency = row.get('currency') != currency

        if is_duplicate or lacks_ref or different_currency:
            review_rows.append(row_id)
            continue

        status = row.get('status')
        amt_abs = abs(row.get('amount_cents', 0))
        if status == 'pending':
            pending_rows.append(row_id)
            pending_credit_cents += amt_abs
        elif status == 'posted':
            matched_rows.append(row_id)
            posted_credit_cents += amt_abs
        else:
            review_rows.append(row_id)

    outstanding_cents = max(0, amount_cents - posted_credit_cents)

    if review_rows:
        status = 'needs_review'
    elif posted_credit_cents >= amount_cents:
        status = 'already_refunded'
    elif pending_credit_cents > 0:
        status = 'pending'
    elif claim.get('as_of') <= claim.get('promised_by'):
        status = 'not_due'
    elif (claim.get('statement_from') > claim.get('promised_by') or
          claim.get('statement_through') < claim.get('promised_by')):
        status = 'coverage_gap'
    elif posted_credit_cents > 0:
        status = 'partially_refunded'
    else:
        status = 'overdue'

    return {
        'status': status,
        'posted_credit_cents': posted_credit_cents,
        'pending_credit_cents': pending_credit_cents,
        'outstanding_cents': outstanding_cents,
        'matched_rows': sorted(matched_rows),
        'pending_rows': sorted(pending_rows),
        'review_rows': sorted(review_rows),
        'statement_through': claim.get('statement_through'),
        'currency': currency,
    }

def main():
    with open('/inputs/request.json', 'r', encoding='utf-8') as f:
        data = json.load(f)

    results = {}
    for job in data.get('jobs', []):
        job_id = job.get('id')
        results[job_id] = process_job(job)

    print(json.dumps({'results': results}, separators=(',', ':')))

if __name__ == '__main__':
    main()