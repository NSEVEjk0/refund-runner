# Refund Runner case packet

Merchant: Northline Outfitters

Promised: $129.00 by 2026-10-30

Finding: overdue

Matching posted credits: $0.00

Pending credits: $0.00

Outstanding through 2026-11-07: $129.00

Amounts and dates are checked against the supplied, customer-reviewed evidence. Document authenticity and transactions outside the supplied coverage are not verified.

The support desk is a practice simulation. No company was contacted and no money was recovered.

The private evidence bundle includes transaction rows. Review it before sharing.
